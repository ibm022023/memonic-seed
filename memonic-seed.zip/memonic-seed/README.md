# GRE-generate-mnemonic-code
Run the following python code with a text file in the same directory containing the words for which you need the mnemonic.
Follow this to run the code:
1. open the python script and change name of the text file containing the list of words. Save and close.
2. Make sure the text file is the same folder as the script. (else give the path too).
3.Run the python script. 
4. Find your output as a csv file in the same folder.

The mnemonics are taken from mnemonicdictionary.com
